from django.apps import AppConfig


class SignuptaskConfig(AppConfig):
    name = 'signuptask'
